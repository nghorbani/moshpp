#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
# Created by Javier Romero on 2016-01-05.

"""
Reposing the alignments
"""

import numpy as np

from .lbs import global_rigid_transformation
from .posemapper import posemap


def parms2transfmatrix(pose, J, kintree_table, weights):
    '''Create pose transformations per vertex
    :param pose: N*3 numpy array of Rodrigues vectors describing model pose
    :param J: Nx3 numpy array of joint positions
    :param kintree_table: 2xN array with kinematic relations. It contains one
        column per joint, with parent in first row and child in the second
    :param weights: N_verticesxN array storing the model blending weights
    :return: global transformation to be applied to each vertex to achieve the desired pose
    '''
    import chumpy as ch
    A, _ = global_rigid_transformation(pose, J, kintree_table, ch)
    return(A.r.dot(weights.T.r))


def unpose_offsets(sm, v, invert_by_transposing=False):
    '''Unposes local offsets according to pose and shape estimated with model sm,
    and adds them back to the template.

    :param sm: Body model used for unposing
    :param v: Vertices to be unposed
    :param invert_by_transposing: Whether the rotation inversion is done by transpose
        or actual inversion. Since the "rotation" matrices are actually linear
        blends of rotations, inversion is more correct but slower.
    :return: Unposed vertices
    '''
    # obtain transformations per vertex
    T = parms2transfmatrix(sm.pose.r, sm.J, sm.kintree_table, sm.weights)
    pmap = posemap(sm.bs_type)
    nverts = sm.v_template.shape[0]
    # rest shape including posedirs, in homogeneous coords
    rest_shape_h = np.vstack((sm.v_template.T.r +
                              sm.posedirs.dot(pmap(sm.pose)).T.r,
                              np.ones((1, nverts))))
    # transform the template with transformations and add translation
    posed_tmpl = sm.trans + np.einsum('ijk,jk->ik', T, rest_shape_h)[:3].T
    diff = v - posed_tmpl

    # compute inverse rotations per vertex
    if invert_by_transposing:
        invR = np.asarray([t[:3, :3].T for t in T.T]).T
    else:
        invR = np.asarray([np.linalg.inv(t[:3, :3]) for t in T.T]).T

    # rotate the offsets between alignment and posed template
    unposed_reg_offset = np.einsum('ijk,jk->ik', invR, diff.T)[:3].T
    # and add them back to the unposed template
    unposed_v = sm.v_template.r + unposed_reg_offset
    return(unposed_v)


def unpose(sm, v):
    '''Unposes directly the vertices v according to pose and shape estimated
    with model sm

    :param sm: Body model used for unposing
    :param v: Vertices to be unposed
    :return: Unposed vertices
    '''
    # obtain transformations per vertex
    T = parms2transfmatrix(sm.pose.r, sm.J, sm.kintree_table, sm.weights)
    nverts = sm.v_template.shape[0]
    pmap = posemap(sm.bs_type)
    # invert transformations per vertex
    invT = np.asarray([np.linalg.inv(t) for t in T.T]).T
    # add a row of ones to the vertices to be unposed
    homog_v = np.vstack(((v - sm.trans).T, np.ones((1, nverts))))
    # multiply each vertex by the inverse transformation, and subtract posedirs
    unposed_v = (np.einsum('ijk,jk->ik', invT, homog_v)[:3].T -
                 sm.posedirs.dot(pmap(sm.pose)))
    return(unposed_v)


def repose_template(sm, template, poses):
    '''Reposes a model given a new v_template

    :param sm: Body model to be reposed
    :param template: Template, in the T pose, to be reposed
    :param list poses: List of poses to be used in the reposing process
    :return: List of reposed vertices
    '''
    sm.v_template[:] = template
    sm.betas[:] = 0.
    reposed_vs = []
    for pose in poses:
        sm.pose[:] = pose
        reposed_vs.append(sm.r)
    return(reposed_vs)
