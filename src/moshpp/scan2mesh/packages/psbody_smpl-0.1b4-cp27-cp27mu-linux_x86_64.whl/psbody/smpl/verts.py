#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2014-2015 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
# Author(s): Matthew Loper


"""
"""

import chumpy
import lbs
import dqbs
import numpy
from posemapper import posemap
import scipy.sparse as sp
from chumpy.ch import MatVecMult


def ischumpy(x):
    return hasattr(x, 'dterms')


def verts_decorated(trans,
                    pose,
                    v_template,
                    J,
                    weights,
                    kintree_table,
                    bs_style,
                    f,
                    bs_type=None,
                    posedirs=None,
                    betas=None,
                    shapedirs=None,
                    want_Jtr=False):

    for which in [trans, pose, v_template, weights, posedirs, betas, shapedirs]:
        if which is not None:
            assert ischumpy(which)

    v = v_template

    if shapedirs is not None:
        if betas is None:
            betas = chumpy.zeros(shapedirs.shape[-1])
        v_shaped = v + shapedirs.dot(betas)
    else:
        v_shaped = v

    if posedirs is not None:
        v_posed = v_shaped + posedirs.dot(posemap(bs_type)(pose))
    else:
        v_posed = v_shaped

    v = v_posed

    if sp.issparse(J):
        regressor = J
        J_tmpx = MatVecMult(regressor, v_shaped[:, 0])
        J_tmpy = MatVecMult(regressor, v_shaped[:, 1])
        J_tmpz = MatVecMult(regressor, v_shaped[:, 2])
        J = chumpy.vstack((J_tmpx, J_tmpy, J_tmpz)).T
    else:
        assert(ischumpy(J))

    if bs_style == 'dqbs':
        result, meta = dqbs.verts_core(pose, v, J, weights, kintree_table, want_Jtr=True, xp=chumpy)
    else:
        assert(bs_style == 'lbs')
        result, meta = lbs.verts_core(pose, v, J, weights, kintree_table, want_Jtr=True, xp=chumpy)

    Jtr = meta.Jtr if meta is not None else None

    tr = trans.reshape((1, 3))
    result = result + tr
    Jtr = Jtr + tr

    result.trans = trans
    result.f = f
    result.pose = pose
    result.v_template = v_template
    result.J = J
    result.weights = weights
    result.kintree_table = kintree_table
    result.bs_style = bs_style
    result.bs_type = bs_type

    if bs_style == 'lbs' and meta is not None:
        for field in ['Jtr', 'A', 'A_global', 'A_weighted']:
            if(hasattr(meta, field)):
                setattr(result, field, getattr(meta, field))

    if posedirs is not None:
        result.posedirs = posedirs
        result.v_posed = v_posed
    if shapedirs is not None:
        result.shapedirs = shapedirs
        result.betas = betas
        result.v_shaped = v_shaped
    if want_Jtr:
        result.J_transformed = Jtr
    return result


def verts_core(pose, v, J, weights, kintree_table, bs_style, want_Jtr=False, xp=chumpy):

    if xp == chumpy:
        assert(hasattr(pose, 'dterms'))
        assert(hasattr(v, 'dterms'))
        assert(hasattr(J, 'dterms'))
        assert(hasattr(weights, 'dterms'))

    if bs_style == 'dqbs':
        result = dqbs.verts_core(pose, v, J, weights, kintree_table, want_Jtr, xp)
    else:
        assert(bs_style == 'lbs')
        result = lbs.verts_core(pose, v, J, weights, kintree_table, want_Jtr, xp)

    return result
