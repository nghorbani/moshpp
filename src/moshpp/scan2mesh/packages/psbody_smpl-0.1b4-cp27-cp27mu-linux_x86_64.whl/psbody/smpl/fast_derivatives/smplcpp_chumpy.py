#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2015 Max Planck Society. All rights reserved.

"""
SMPL fitting wit fast derivatives
---------------------------------
"""

import chumpy as ch

from ..verts import verts_decorated
from .smpl_derivatives import lbs_derivatives_wrt_pose, lbs_derivatives_wrt_shape


def _get_lowres(model, indices):
    import numpy as np

    def subset(x):
        return ch.array(np.asarray(x)[indices].copy())

    posedirs = subset(model.posedirs.r)
    shapedirs = subset(model.shapedirs.r)
    weights = subset(model.weights.r)
    v_template = subset(model.v_template.r)
    return (posedirs, shapedirs, weights, v_template)


class SmplModelLBS(ch.Ch):
    dterms = ['trans', 'pose', 'betas']

    # low_res is used to obtain a lower-res model; it is a dict with keys 'vids' and 'faces'
    # (vertex ids to retain, faces for the lower-res model)
    def __init__(self, trans, pose, betas, model, low_res=None):

        from chumpy.ch import MatVecMult
        import numpy as np

        assert(model.bs_style == 'lbs')

        if low_res is not None:
            indices = low_res['vids']
            faces = low_res['faces']

            Jdirs = np.dstack([model.J_regressor.dot(model.shapedirs[:, :, i]) for i in range(len(self.betas))])
            self.J_predicted = ch.array(Jdirs).dot(self.betas) + model.J_regressor.dot(model.v_template.r)
            (posedirs, shapedirs, weights, v_template) = _get_lowres(model, indices)
        else:
            faces = model.f
            posedirs = model.posedirs
            shapedirs = model.shapedirs
            weights = model.weights

            v_template = ch.array(model.v_template.r)
            v_shaped = v_template + shapedirs[:, :, :len(self.betas)].dot(self.betas)
            J_tmpx = MatVecMult(model.J_regressor, v_shaped[:, 0])
            J_tmpy = MatVecMult(model.J_regressor, v_shaped[:, 1])
            J_tmpz = MatVecMult(model.J_regressor, v_shaped[:, 2])
            self.J_predicted = ch.vstack((J_tmpx, J_tmpy, J_tmpz)).T

        self.J = self.J_predicted

        self._inner_model = verts_decorated(trans=self.trans,
                                            pose=self.pose,
                                            v_template=v_template,
                                            J=self.J,
                                            weights=weights,
                                            kintree_table=model.kintree_table,
                                            bs_style=model.bs_style,
                                            f=faces,
                                            bs_type=model.bs_type,
                                            posedirs=posedirs,
                                            betas=self.betas,
                                            shapedirs=shapedirs[:, :, :len(self.betas)])

        # this seems to be required for betas derivatives
        self._inner_model.J_regressor = model.J_regressor

    def compute_r(self):
        return self._inner_model.r

    def compute_dr_wrt(self, wrt):
        if wrt is self.pose:
            return lbs_derivatives_wrt_pose(self._inner_model)

        if wrt is self.betas:
            return lbs_derivatives_wrt_shape(self._inner_model)

        return self._inner_model.dr_wrt(wrt)
