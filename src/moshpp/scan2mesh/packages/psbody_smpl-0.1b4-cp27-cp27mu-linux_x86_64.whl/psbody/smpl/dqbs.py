#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2014-2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
# Author(s): Matthew Loper

"""
SMPL Dual Quaternion Blend Shapes
---------------------------------

"""


import chumpy
import numpy as np
from chumpy.ch import MatVecMult
import scipy.sparse as sp

try:
    import compiled.smpl
    have_compiled = True
except:
    have_compiled = False


def safe_divide(a, b):
    if hasattr(a, 'dterms') or hasattr(b, 'dterms'):
        result = chumpy.NanDivide(a, b)
    else:  # numpy
        result = a / b
        tmp = result.ravel()
        tmp[np.isinf(tmp)] = 0
        tmp[np.isnan(tmp)] = 0
        result = tmp.reshape(result.shape)
    return result


def quaternion_about_axis(angle, axis, xp):
    """Return quaternion for rotation about axis.

    >>> q = quaternion_about_axis(0.123, [1, 0, 0])
    >>> numpy.allclose(q, [0.99810947, 0.06146124, 0, 0])
    True

    """

    q0 = xp.cos(angle / 2.)
    q_rest = safe_divide(axis * xp.sin(angle / 2.), xp.linalg.norm(axis))
    r1 = xp.concatenate((xp.atleast_1d(q0), q_rest))
    return r1


def quaternions_about_axes(angles, axes, xp):
    angles = angles.reshape((-1, 1))
    q0 = xp.cos(angles / 2.)

    xnorm = lambda x : xp.sqrt(xp.sum(x ** 2., axis=1)).reshape((-1, 1))
    q_rest = safe_divide(axes * xp.sin(angles / 2.), xnorm(axes))
    r1 = xp.hstack((q0, q_rest))
    return r1


def normalize(x, xp):
    return safe_divide(x, xp.sqrt(xp.sum(x ** 2., axis=1).reshape((-1, 1))))


def verts_internal(qrots, qtrans, v, weights, xp):

    c_0 = weights.dot(normalize(qrots, xp))
    c_e = weights.dot(qtrans)

    denom = xp.sqrt(xp.sum(c_0 ** 2., axis=1).reshape((-1, 1)))

    c_0 = safe_divide(c_0, denom)
    c_e = safe_divide(c_e, denom)

    a_0 = c_0[:, 0].reshape((-1, 1))
    d_0 = c_0[:, 1:]
    a_e = c_e[:, 0].reshape((-1, 1))
    d_e = c_e[:, 1:]

    result = (v +
              xp.cross((d_0 * 2), (xp.cross(d_0, v) + a_0 * v)) +
              2 * (a_0 * d_e - a_e * d_0 + xp.cross(d_0, d_e))
              )
    return result


def quats_from_aa(aa, xp):
    angles = xp.sqrt(xp.sum(aa ** 2, axis=1))

    axes = safe_divide(aa, angles.reshape((-1, 1)))
    # axes = aa / angles.reshape((-1,1))

    if False:
        result = [quaternion_about_axis(angles[i], axes[i], xp) for i in range(aa.shape[0])]
        result = xp.vstack(result)
    else:
        result = quaternions_about_axes(angles, axes, xp)
    result = safe_divide(result, xp.sqrt(xp.sum(result ** 2., axis=1)).reshape((-1, 1)))
    return result


tmp0_mtx = np.eye(4)[:, np.array([0, 1, 2, 3])] * np.array([[+1, -1, -1, -1]])
tmp1_mtx = np.eye(4)[:, np.array([1, 0, 3, 2])] * np.array([[+1, +1, +1, -1]])
tmp2_mtx = np.eye(4)[:, np.array([2, 3, 0, 1])] * np.array([[+1, -1, +1, +1]])
tmp3_mtx = np.eye(4)[:, np.array([3, 2, 1, 0])] * np.array([[+1, +1, -1, +1]])
tmps_hstacked = np.hstack((tmp0_mtx, tmp1_mtx, tmp2_mtx, tmp3_mtx))
tmps_vstacked = np.vstack((tmp0_mtx, tmp1_mtx, tmp2_mtx, tmp3_mtx))


class QuatsMultiply(chumpy.Ch):
    dterms = 'q0', 'q1'

    def on_changed(self, which):
        if 'q1' in which:
            self.q1_dot_tmps_dstacked = self.q1.r.dot(tmps_hstacked).reshape((-1, 4, 4))

    def compute_r(self):
        return np.einsum('abc,ac->ab', self.q1_dot_tmps_dstacked, self.q0.r.reshape((-1, 4)))
        # return self.q1_dot_tmps_hstacked.dot(self.q0.r)

    def compute_dr_wrt(self, wrt):
        if (wrt is not self.q0 and wrt is not self.q1):
            return None

        sz = self.q0.size
        result = np.zeros((sz, sz))
        if wrt is self.q0:
            result += sp.block_diag([mtx for mtx in self.q1_dot_tmps_dstacked]).todense()
        if wrt is self.q1:
            mtxs = self.q0.r.dot(tmps_vstacked.T).reshape((-1, 4, 4))
            result += sp.block_diag([mtx for mtx in mtxs]).todense()
        if self.q0.size > 4:
            result = sp.csc_matrix(result)
        return result


def quats_multiply(q0, q1, xp):
    if xp == chumpy:
        return QuatsMultiply(q0, q1)

    q0 = q0.reshape((-1, 4))
    q1 = q1.reshape((-1, 4))

    tmp0 = q1[:, np.array([0, 1, 2, 3])] * np.array([[+1, -1, -1, -1]])
    tmp1 = q1[:, np.array([1, 0, 3, 2])] * np.array([[+1, +1, +1, -1]])
    tmp2 = q1[:, np.array([2, 3, 0, 1])] * np.array([[+1, -1, +1, +1]])
    tmp3 = q1[:, np.array([3, 2, 1, 0])] * np.array([[+1, +1, -1, +1]])

    a = xp.sum(tmp0 * q0, axis=1).reshape((-1, 1))
    b = xp.sum(tmp1 * q0, axis=1).reshape((-1, 1))
    c = xp.sum(tmp2 * q0, axis=1).reshape((-1, 1))
    d = xp.sum(tmp3 * q0, axis=1).reshape((-1, 1))

    return xp.hstack((a, b, c, d))


def dual_quats_multiply(qtr1, qrt1, qtr2, qrt2, xp):
    qrt = quats_multiply(qrt1, qrt2, xp)
    qtr = quats_multiply(qtr1, qrt2, xp) + quats_multiply(qrt1, qtr2, xp)
    return qrt, qtr


def quat_global_rigid_transformation(pose, J, kintree_table, xp):

    pose = pose.reshape((-1, 3))
    quats_local = quats_from_aa(pose, xp)

    njoints = kintree_table.shape[1]
    id_to_col = {kintree_table[1, i]: i for i in range(njoints)}
    parent = {i: id_to_col[kintree_table[0, i]] for i in range(1, njoints)}

    tmp = [J[parent[i]] for i in range(1, J.shape[0])]
    tmp = xp.vstack(tmp)
    tmp = xp.vstack((xp.array([[0., 0., 0.]]), tmp))
    trans_relative = J - tmp

    trans = []
    qrots = []

    # Turn joint location differences into DQ translations
    tstacked = xp.hstack((np.zeros((trans_relative.shape[0], 1)), trans_relative)) * .5
    qtrans_local = quats_multiply(tstacked, quats_local, xp)

    qrots.append(quats_from_aa(pose[0].reshape((1, -1)), xp).ravel())
    trans.append(xp.array([0., 0., 0., 0.]))

    for i in range(1, kintree_table.shape[1]):
        parent_trans = trans[parent[i]]
        parent_qrot = qrots[parent[i]]

        qrot, tra = dual_quats_multiply(parent_trans, parent_qrot, qtrans_local[i], quats_local[i], xp)
        # qrot, tra = dual_quats_multiply(qtrans_local[i], quats_local[i], parent_trans, parent_qrot, xp)
        qrots.append(qrot)
        trans.append(tra)

    qrots = xp.vstack(qrots)
    trans = xp.vstack(trans)

    # trans_putback = xp.array(np.hstack((np.zeros((trans.shape[0], 1)), -J/2.)))
    trans_putback = xp.hstack((xp.zeros((trans.shape[0], 1)), -J / 2.))
    rot_putback = xp.array([1., 0., 0., 0.])

    qrots_no_putback = xp.vstack(qrots)
    trans_no_putback = xp.vstack(trans)
    tmp = [dual_quats_multiply(trans[i], qrots[i], trans_putback[i], rot_putback, xp) for i in range(trans.shape[0])]
    qrots = [t[0] for t in tmp]
    trans = [t[1] for t in tmp]
    qrots = xp.vstack(qrots)
    trans = xp.vstack(trans)

    return qrots, trans, qrots_no_putback, trans_no_putback


def blendfunc(bs_type):
    from posemapper import posemap
    return posemap(bs_type)


def compute_J_transformed(qtrans, qrots, qtrans_no_pb, qrots_no_pb, xp=chumpy):
    tq = qtrans_no_pb
    rq = qrots_no_pb / xp.sqrt(xp.sum(qrots ** 2., axis=1)).reshape((-1, 1))
    tx = 2.0 * (-tq[:, 0] * rq[:, 1] + tq[:, 1] * rq[:, 0] - tq[:, 2] * rq[:, 3] + tq[:, 3] * rq[:, 2])
    ty = 2.0 * (-tq[:, 0] * rq[:, 2] + tq[:, 1] * rq[:, 3] + tq[:, 2] * rq[:, 0] - tq[:, 3] * rq[:, 1])
    tz = 2.0 * (-tq[:, 0] * rq[:, 3] - tq[:, 1] * rq[:, 2] + tq[:, 2] * rq[:, 1] + tq[:, 3] * rq[:, 0])
    return xp.vstack((tx, ty, tz)).T


def verts_core(pose, v, J, weights, kintree_table, want_Jtr=False, xp=chumpy):

    if xp != chumpy and have_compiled:
        return compiled.smpl.verts_dqbs(pose, v, J, weights, kintree_table, want_Jtr)

    qrots, qtrans, qrots_nopb, qtrans_nopb = quat_global_rigid_transformation(pose, J, kintree_table, xp=xp)
    verts = verts_internal(qrots, qtrans, v, weights, xp)

    # if xp == chumpy:
    #     verts.f = f
    #     verts.pose = pose
    #     verts.J = J
    #     verts.kintree_table = kintree_table
    #     verts.weights = weights
    #     verts.qrots = qrots
    #     verts.qtrans = qtrans
    #     verts.v_rest = v

    class result_meta(object):
        pass

    meta = result_meta()

    Jtr = None
    if want_Jtr:
        Jtr = compute_J_transformed(qtrans, qrots, qtrans_nopb, qrots_nopb, xp)

    meta.Jtr = Jtr

    return verts, meta


def verts_posed(trans, pose, v_template, J, weights, kintree_table, blendshapes, bs_type, want_Jtr=False, xp=chumpy):

    if trans.shape != (1, 3):
        trans = trans.reshape((1, 3))

    if xp != chumpy and have_compiled:
        return compiled.smpl.verts_posed(trans, pose, v_template, J, weights, kintree_table, blendshapes, bs_type, want_Jtr)

    v_posed = v_template + blendshapes.dot(blendfunc(bs_type)(pose))
    verts = verts_core(pose, v_posed, J, weights, kintree_table, xp) + trans

    if not want_Jtr:
        return verts

    J_transformed = compute_J_transformed(qtrans, qrots, qtrans_nopb, qrots_nopb, xp) + trans
    return verts, J_transformed


def verts_shaped(trans, pose, betas, v_template, J_regressor, weights, kintree_table, blendshapes, bs_type, shapedirs, xp=chumpy, want_Jtr=False):

    if trans.shape != (1, 3):
        trans = trans.reshape((1, 3))

    v_shaped = v_template + shapedirs.dot(betas)

    if xp == chumpy:
        J_pred = MatVecMult(J_regressor, v_shaped)
    else:
        J_pred = J_regressor.dot(v_shaped)

    return verts_posed(trans, pose, v_shaped, J_pred, weights, kintree_table, blendshapes, bs_type, want_Jtr=want_Jtr, xp=xp)


def verts(pose, trans, J, kintree_table, v_shaped, v_template, weights, blendshapes, bs_type, f, xp=chumpy):

    if xp == chumpy:
        assert(v_shaped.dr_wrt(v_template) is not None)

    qrots, qtrans, qrots_nopb, qtrans_nopb = quat_global_rigid_transformation(pose, J, kintree_table, xp=xp)

    v_posed = v_shaped + blendshapes.dot(blendfunc(bs_type)(pose))
    vv = verts_internal(qrots, qtrans, v_posed, weights, xp) + trans.reshape((1, 3))

    if xp == np:
        return vv

    vv.r

    vv.f = f
    vv.trans = trans
    vv.pose = pose
    vv.J = J
    vv.kintree_table = kintree_table
    vv.weights = weights
    vv.bs_type = bs_type
    vv.blendshapes = blendshapes
    vv.qrots = qrots
    vv.qtrans = qtrans
    vv.v_template = v_template
    vv.v_shaped = v_shaped
    vv.v_posed = v_posed
    # vv.J_naive = ???

    tq = qtrans_nopb
    rq = qrots_nopb / xp.sqrt(xp.sum(qrots ** 2., axis=1)).reshape((-1, 1))
    tx = 2.0 * (-tq[:, 0] * rq[:, 1] + tq[:, 1] * rq[:, 0] - tq[:, 2] * rq[:, 3] + tq[:, 3] * rq[:, 2])
    ty = 2.0 * (-tq[:, 0] * rq[:, 2] + tq[:, 1] * rq[:, 3] + tq[:, 2] * rq[:, 0] - tq[:, 3] * rq[:, 1])
    tz = 2.0 * (-tq[:, 0] * rq[:, 3] - tq[:, 1] * rq[:, 2] + tq[:, 2] * rq[:, 1] + tq[:, 3] * rq[:, 0])

    # vv.J_transformed = qtrans[:,1:]*2.+J + trans.reshape((1,3))
    vv.J_transformed = xp.vstack((tx, ty, tz)).T + trans.reshape((1, 3))

    return vv
