#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2015-2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
__version__ = '0.1.b4'
