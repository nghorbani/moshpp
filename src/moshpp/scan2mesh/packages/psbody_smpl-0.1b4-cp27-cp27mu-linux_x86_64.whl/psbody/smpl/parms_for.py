#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information

"""
Optimization of a model parameters wrt. data
"""

import numpy as np
import chumpy as ch

from .utilities import get_vertices_per_edge


def parms_for(model, mesh_v, num_betas_to_optimize=0, opt_callback=None,
              on_edges=False, is_cpp=True, optimize_parts_iteratively=False):
    ''' Function that optimizes parameters of a model so that it fits an alignment.
    :param model: Body model whose parameters have to be estimated
    :param mesh_v: Array Nx3 with vertices to be fit by the parameterized model
    :param num_betas_to_optimize: Number of shape parameters to optimize. If equal to zero, no shape optimization is performed
    :param opt_callback: If not None, function to be called in each optimizer iteration
    :param on_edges: Whether the data term of the objective measure distances between edges or vertices
    :param is_cpp: Whether c++ derivatives are used during optimization or not
    :param optimize_parts_iteratively: Whether the pose optimization iterates over the model kinematics or happens all at once.
    :return: a model with optimized parameters that fit mesh_v
    '''
    # this was to avoid a problem with chumpy when dealing with all zero arrays
    init_pose = model.pose.r * 0. + 1e-16
    init_trans = model.trans.r * 0. + 1e-16

    n_shape_comps = model.betas.r.size
    betas_padd = np.hstack((model.betas.r[:num_betas_to_optimize], np.zeros(n_shape_comps - num_betas_to_optimize)))

    if is_cpp:
        from .fast_derivatives.smplcpp_chumpy import SmplModelLBS
        # use the wrapper for c++ derivatives (very similar to the old ScapeVerts)
        # calls to compute_dr_wrt are just redirected to the c++ implementation
        sv = SmplModelLBS(trans=ch.array(init_trans), pose=ch.array(init_pose),
                          betas=ch.array(betas_padd), model=model)
    else:
        from .verts import verts_decorated
        # use the wrapper for relying only on python/chumpy
        sv = verts_decorated(trans=ch.array(init_trans),
                             pose=ch.array(init_pose),
                             v_template=model.v_template,
                             J=model.J_regressor,
                             betas=ch.array(betas_padd),
                             shapedirs=model.shapedirs,
                             weights=model.weights,
                             kintree_table=model.kintree_table,
                             bs_style=model.bs_style,
                             f=model.f,
                             bs_type=model.bs_type,
                             posedirs=model.posedirs)

    # set up edge objective
    vpe = get_vertices_per_edge(sv.r, model.f)

    def edges_for(x):
        return(x[vpe[:, 0]] - x[vpe[:, 1]])

    edge_obj = edges_for(sv) - edges_for(mesh_v)

    # set up vertex objective
    vert_obj = sv - mesh_v

    nposeparms = model.pose.ravel().size

    # set the function that will be called at each optimization iteration
    if opt_callback is not None:
        def on_step(_):
            opt_callback(sv.r)
    else:
        on_step = None

    # optimize the first three pose parameters, i.e. the body's orientation
    ch.minimize([edge_obj], x0=[sv.pose[:3]], callback=on_step,
                options={'maxiter': 10})

    if optimize_parts_iteratively:
        # careful optimization iterating over pose parameters
        for ii in np.arange(3, nposeparms, 3):
            ch.minimize([edge_obj, 4 * sv.pose[ii - 3:ii]], x0=[sv.pose[:ii]],
                        callback=on_step, options={'e_3': .1})
    else:
        # optimize all the pose parameters together (to use e.g. if the initialization is already close)
        ch.minimize(edge_obj, x0=[sv.pose], callback=on_step,
                    options={'e_3': .1})

    if not on_edges:
        ch.minimize(vert_obj, x0=[sv.trans], callback=on_step,
                    options={'maxiter': 1})

    trans_maybe = [] if on_edges else [sv.trans]
    final_obj = edge_obj if on_edges else vert_obj

    if num_betas_to_optimize > 0.:
        sv.betas[:] = 0.
        ch.minimize(final_obj, callback=on_step, options={'e_3': .00001},
                    x0=trans_maybe + [sv.pose, sv.betas[:num_betas_to_optimize]])
    else:
        ch.minimize(final_obj, x0=trans_maybe + [sv.pose], callback=on_step,
                    options={'e_3': .00001})
    return sv
