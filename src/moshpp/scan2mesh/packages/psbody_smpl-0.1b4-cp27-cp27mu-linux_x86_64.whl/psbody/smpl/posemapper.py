#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2015-2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
# Author(s): Matthew Loper


import chumpy as ch
import numpy as np

# this one is a differentiable chumpy Rodrigues transform
from .rodrigues import Rodrigues

# this one is a reimplementation of the OpenCV Rodrigues transform
from fast_derivatives.smpl_derivatives import Rodrigues as cv2Rodrigues


def aa_raw(p):
    return p.ravel()


def laa_raw(p):
    return p.ravel()[3:]


def rotmtx(p):
    if isinstance(p, np.ndarray):
        return np.concatenate([(cv2Rodrigues(np.array(pp))[0]).ravel() for pp in p.reshape((-1, 3))]).ravel()
    if p.shape[0] == p.size:
        p = p.reshape((-1, 3))
    return ch.concatenate([Rodrigues(pp).ravel() for pp in p]).ravel()


def rotmin(p):
    if isinstance(p, np.ndarray):
        return np.concatenate([(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()
    if p.shape[0] == p.size:
        p = p.reshape((-1, 3))
    return ch.concatenate([(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()


def lrotmin(p):
    if isinstance(p, np.ndarray):
        p = p.ravel()[3:]
        return np.concatenate([(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()
    if p.ndim != 2 or p.shape[1] != 3:
        p = p.reshape((-1, 3))
    p = p[1:]
    return ch.concatenate([(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()


def lrotmin2rhandpca(p):
    lrotmin2pca = ch.asarray(np.load('/ps/body/projects/hands/data/rhand_lrotmin2pca.npy'))
    if isinstance(p, np.ndarray):
        p = p.ravel()[3:]
        return lrotmin2pca.dot(np.concatenate([(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()).ravel()
    if p.ndim != 2 or p.shape[1] != 3:
        p = p.reshape((-1, 3))
    p = p[1:]
    return lrotmin2pca.dot(ch.concatenate([(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()).ravel()


def lrotmin2rhandpca50(p):
    lrotmin2pca = ch.asarray(np.load('/ps/body/projects/hands/data/rhand_lrotmin2pca50.npy'))
    if isinstance(p, np.ndarray):
        p = p.ravel()[3:]
        return lrotmin2pca.dot(np.concatenate([(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()).ravel()
    if p.ndim != 2 or p.shape[1] != 3:
        p = p.reshape((-1, 3))
    p = p[1:]
    return lrotmin2pca.dot(ch.concatenate([(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()).ravel()


def arotmin(p):
    if isinstance(p, np.ndarray):
        return np.concatenate([p.ravel()] + [(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()
    if p.shape[0] == p.size:
        p = p.reshape((-1, 3))
    return ch.concatenate([p.ravel()] + [(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()


def larotmin(p):
    if isinstance(p, np.ndarray):
        p = p.ravel()[3:]
        return np.concatenate([p.ravel()] + [(cv2Rodrigues(np.array(pp))[0] - np.eye(3)).ravel() for pp in p.reshape((-1, 3))]).ravel()
    if p.ndim != 2 or p.shape[1] != 3:
        p = p.reshape((-1, 3))
    p = p[1:]
    return ch.concatenate([p.ravel()] + [(Rodrigues(pp) - ch.eye(3)).ravel() for pp in p]).ravel()


def cos(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.cos(p) - 1.
    return ch.cos(p) - 1.


def sin(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.sin(p)
    return ch.sin(p)


def aa_cos(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.concatenate([p, np.cos(p) - 1.])
    return ch.concatenate([p, ch.cos(p) - 1.])


def aa_cos_sin(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.concatenate([p, np.cos(p) - 1., np.sin(p)])
    return ch.concatenate([p, ch.cos(p) - 1., ch.sin(p)])


def aa_cos_sq(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.concatenate([p, np.cos(p) - 1., p ** 2.])
    return ch.concatenate([p, ch.cos(p) - 1., p ** 2.])


def aa_sq_cub(p):
    p = p.ravel()
    if isinstance(p, np.ndarray):
        return np.concatenate([p, p ** 2., p ** 3.])
    return ch.concatenate([p, p ** 2., p ** 3.])


def aa_cos_special1(p):
    p = p.ravel()

    ltdiff = 0.25 * (p[55] + np.pi / 2.) ** 2.
    rtdiff = 0.25 * (p[58] - np.pi / 2.) ** 2.
    if isinstance(p, np.ndarray):
        return np.concatenate([p, np.cos(p) - 1., [np.exp(ltdiff)], [np.exp(rtdiff)]])
    return ch.concatenate([p, ch.cos(p) - 1., ch.exp(ltdiff), ch.exp(rtdiff)])


def nothing(p):
    return ch.array([0.])
# 54, (55), 56
#
# 57, (58), 59


def posemap(s):
    if s == 'aa_raw':
        return aa_raw
    elif s == 'laa_raw':
        return laa_raw
    elif s == 'rotmtx':
        return rotmtx
    elif s == 'aa_cos':
        return aa_cos
    elif s == 'nothing':
        return nothing
    elif s == 'aa_cos_sin':
        return aa_cos_sin
    elif s == 'aa_cos_sq':
        return aa_cos_sq
    elif s == 'aa_sq_cub':
        return aa_sq_cub
    elif s == 'rotmin':
        return rotmin
    elif s == 'arotmin':
        return arotmin
    elif s == 'lrotmin':
        return lrotmin
    elif s == 'lrotmin2rhandpca50':
        return lrotmin2rhandpca50
    elif s == 'lrotmin2rhandpca':
        return lrotmin2rhandpca
    elif s == 'larotmin':
        return larotmin
    elif s == 'aa_cos_special1':
        return aa_cos_special1
    elif s == 'cos':
        return cos
    elif s == 'sin':
        return sin
    else:
        raise Exception('Unknown pose: %s' % (str(s),))
