#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2014-2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information
# Author(s): Matthew Loper


import numpy as np
import cPickle as pickle
import chumpy as ch
from chumpy.ch import MatVecMult
from .posemapper import posemap


__all__ = ['load_model', 'save_model']


def save_model(model, fname):
    m0 = model
    trainer_dict = {'v_template': np.asarray(m0.v_template),
                    'J': np.asarray(m0.J),
                    'weights': np.asarray(m0.weights),
                    'kintree_table': m0.kintree_table,
                    'f': m0.f,
                    'bs_type': m0.bs_type,
                    'posedirs': np.asarray(m0.posedirs)
                    }

    if hasattr(model, 'pose_training_info'):
        trainer_dict['pose_training_info'] = m0.pose_training_info
    if hasattr(model, 'shape_training_info'):
        trainer_dict['shape_training_info'] = m0.shape_training_info
    if hasattr(model, 'training_mabs'):
        trainer_dict['training_mabs'] = m0.training_mabs
    if hasattr(model, 'J_regressor'):
        trainer_dict['J_regressor'] = m0.J_regressor
    if hasattr(model, 'J_regressor_prior'):
        trainer_dict['J_regressor_prior'] = m0.J_regressor_prior
    if hasattr(model, 'weights_prior'):
        trainer_dict['weights_prior'] = m0.weights_prior
    if hasattr(model, 'shapedirs'):
        trainer_dict['shapedirs'] = m0.shapedirs
    if hasattr(model, 'shape_subjects'):
        trainer_dict['shape_subjects'] = m0.shape_subjects
    if hasattr(model, 'pose_subjects'):
        trainer_dict['pose_subjects'] = m0.pose_subjects
    if hasattr(model, 'vert_sym_idxs'):
        trainer_dict['vert_sym_idxs'] = m0.vert_sym_idxs

    if hasattr(model, 'bs_style'):
        trainer_dict['bs_style'] = model.bs_style
    else:
        trainer_dict['bs_style'] = 'dqbs'
    pickle.dump(trainer_dict, open(fname, 'w'), -1)


def backwards_compatibility_replacements(dd):

    # replacements
    if 'default_v' in dd:
        dd['v_template'] = dd['default_v']
        del dd['default_v']
    if 'template_v' in dd:
        dd['v_template'] = dd['template_v']
        del dd['template_v']
    if 'joint_regressor' in dd:
        dd['J_regressor'] = dd['joint_regressor']
        del dd['joint_regressor']
    if 'blendshapes' in dd:
        dd['posedirs'] = dd['blendshapes']
        del dd['blendshapes']
    if 'J' not in dd:
        dd['J'] = dd['joints']
        del dd['joints']

    # defaults
    if 'bs_style' not in dd:
        dd['bs_style'] = 'dqbs'


def ready_arguments(fname_or_dict):

    if not isinstance(fname_or_dict, dict):
        dd = pickle.load(open(fname_or_dict))
    else:
        dd = fname_or_dict

    backwards_compatibility_replacements(dd)

    want_shapemodel = 'shapedirs' in dd
    nposeparms = dd['kintree_table'].shape[1] * 3

    if 'trans' not in dd:
        dd['trans'] = np.zeros(3)
    if 'pose' not in dd:
        dd['pose'] = np.zeros(nposeparms)
    if 'shapedirs' in dd and 'betas' not in dd:
        dd['betas'] = np.zeros(dd['shapedirs'].shape[-1])

    for s in ['v_template', 'weights', 'posedirs', 'pose', 'trans', 'shapedirs', 'betas', 'J']:
        if (s in dd) and not hasattr(dd[s], 'dterms'):
            dd[s] = ch.array(dd[s])

    if want_shapemodel:
        dd['v_shaped'] = dd['shapedirs'].dot(dd['betas']) + dd['v_template']
        v_shaped = dd['v_shaped']
        J_tmpx = MatVecMult(dd['J_regressor'], v_shaped[:, 0])
        J_tmpy = MatVecMult(dd['J_regressor'], v_shaped[:, 1])
        J_tmpz = MatVecMult(dd['J_regressor'], v_shaped[:, 2])
        dd['J'] = ch.vstack((J_tmpx, J_tmpy, J_tmpz)).T
        dd['v_posed'] = v_shaped + dd['posedirs'].dot(posemap(dd['bs_type'])(dd['pose']))
    else:
        dd['v_posed'] = dd['v_template'] + dd['posedirs'].dot(posemap(dd['bs_type'])(dd['pose']))

    return dd


def load_model(fname_or_dict):
    """Returns a SMPL model

    Attributes
    ==========

    - `pose` pose parameters
    - `v_posed`: vertices of the rest pose
    - `trans`: global translation
    - `posedirs`: poses directory (variation of the rest pose according to pose)

    Optional
    --------

    - `v_shaped`: vertices of the template rest pose with shape parameters applied
    - `A`: kinematic tree transformation in world coordinates
    - `A_global`:  kinematic tree transformation in relative coordinates
    - `A_weighted`: application of the weight matrix to `A`
    """

    from .verts import verts_core

    dd = ready_arguments(fname_or_dict)

    want_shapemodel = 'shapedirs' in dd
    args = {
        'pose': dd['pose'],
        'v': dd['v_posed'],
        'J': dd['J'],
        'weights': dd['weights'],
        'kintree_table': dd['kintree_table'],
        'xp': ch,
        'want_Jtr': True,
        'bs_style': dd['bs_style'],
    }

    result_previous, meta = verts_core(**args)
    result = result_previous + dd['trans'].reshape((1, 3))
    result.no_translation = result_previous

    if meta is not None:
        for field in ['Jtr', 'A', 'A_global', 'A_weighted']:
            if(hasattr(meta, field)):
                setattr(result, field, getattr(meta, field))

    if hasattr(result, 'Jtr'):
        result.J_transformed = result.Jtr + dd['trans'].reshape((1, 3))

    for k, v in dd.items():
        setattr(result, k, v)

    return result
