#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2015-2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information

"""
Some utilities for vertices and edges
"""

import numpy as np


def _get_cache_folder():
    """Returns a folder used for caching some intermediate processing"""
    import sys
    if sys.platform.find("linux") > -1:
        return "/tmp"

    import tempfile
    return tempfile.gettempdir()


def get_vert_connectivity(mesh_v, mesh_f):
    """Returns a sparse matrix (of size #verts x #verts) where each nonzero
    element indicates a neighborhood relation. For example, if there is a
    nonzero element in position (15,12), that means vertex 15 is connected
    by an edge to vertex 12."""
    import scipy.sparse as sp

    vpv = sp.csc_matrix((len(mesh_v), len(mesh_v)))

    # for each column in the faces...
    for i in range(3):
        IS = mesh_f[:, i]
        JS = mesh_f[:, (i + 1) % 3]
        data = np.ones(len(IS))
        ij = np.vstack((IS.flatten().reshape((1, -1)),
                        JS.flatten().reshape((1, -1))))
        mtx = sp.csc_matrix((data, ij), shape=vpv.shape)
        vpv = vpv + mtx + mtx.T

    return vpv


def get_vertices_per_edge(mesh_v, mesh_f):
    """Returns an Ex2 array of adjacencies between vertices, where
    each element in the array is a vertex index. Each edge is included
    only once. If output of get_faces_per_edge is provided, this is used to
    avoid call to get_vert_connectivity()"""
    import zlib
    import os
    import pickle
    import scipy.sparse as sp

    faces = mesh_f
    cached_file_name = 'verts_per_edge_cache_%s.pkl' % str(zlib.crc32(faces.flatten()))
    cache_fname = os.path.join(_get_cache_folder(), cached_file_name)
    try:
        with open(cache_fname, 'rb') as fp:
            return(pickle.load(fp))
    except:
        vc = sp.coo_matrix(get_vert_connectivity(mesh_v, mesh_f))
        result = np.hstack((vc.row.reshape((-1, 1)),
                            vc.col.reshape((-1, 1))))
        result = result[result[:, 0] < result[:, 1]]  # for uniqueness

        with open(cache_fname, 'wb') as fp:
            pickle.dump(result, fp, -1)
        return result
