#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2014-2015 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information

# Author(s): Matthew Loper

"""
Pose normalization
------------------

"""

from chumpy.ch import MatVecMult
import chumpy as ch
import numpy as np

from .utilities import get_vertices_per_edge


def pose_normalize(model, J_regressor, registration, show=False):

    v_template = model.v_template
    Jx = MatVecMult(J_regressor, v_template[:, 0])
    Jy = MatVecMult(J_regressor, v_template[:, 1])
    Jz = MatVecMult(J_regressor, v_template[:, 2])
    J_predicted = ch.vstack((Jx, Jy, Jz)).T

    vpe = get_vertices_per_edge(model.r, model.f)

    def edges_for(x):
        return x[vpe[:, 0]] - x[vpe[:, 1]]

    model.pose[:] = model.pose.r + 1e-10

    for kk in range(2):
        objective = {'data': model - registration.v}
        ch.minimize(objective, x0=[model.trans, model.pose[:3]], options={'e_3': .001})

        objective = {'data': edges_for(model) - edges_for(registration.v), }
        ch.minimize(objective, x0=[model.pose], options={'e_3': .001})

    if True:  # works with nnls
        objective = {
            'data': model - registration.v,
            'J_reg': J_predicted - model.J
        }
        try:
            ch.minimize(objective, x0=[model.v_template, model.J], options={'e_3': .001})
        except:
            ch.minimize({'data': model - registration.v}, x0=[model.v_template], options={'e_3': .001})
    else:
        objective = {'data': model - registration.v}
        for kk in range(10):
            ch.minimize(objective, x0=[model.v_template], options={'e_3': .001})
            model.J[:] = np.asarray(J_predicted)

    return model.v_template.r
