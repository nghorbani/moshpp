#!/usr/bin/env python
# encoding: utf-8
# Copyright (c) 2016 Max Planck Society. All rights reserved.
# See accompanying LICENSE.txt file for licensing and contact information

from fast_derivatives.smpl_derivatives import Rodrigues as _Rodrigues
from chumpy import Ch
import numpy as np


class Rodrigues(Ch):
    dterms = 'rt'

    def compute_r(self):
        return np.asarray(_Rodrigues(self.rt.r)[0]).reshape((3, 3))

    def compute_dr_wrt(self, wrt):
        if wrt is self.rt:
            return np.asarray(_Rodrigues(self.rt.r)[1]).T
